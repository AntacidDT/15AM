package com.annoyances.forJava;

import java.util.Random;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class BlockTemperAnnoyance {
    private static final Random RANDOM = new Random();

    public static void onBlockBreak(class_3218 level, class_3222 player, class_2338 pos) {
        if (AnnoyanceManager.getForPlayer(level, player) != Annoyance.BLOCK_TEMPER) return;

        double chance = 0.3 + RANDOM.nextDouble() * 0.3;
        if (RANDOM.nextDouble() >= chance) return;

        level.method_8537(null,
                pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                3.0f, false, class_1937.class_7867.field_40891);
    }
}
