package com.annoyances.forJava;

import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1352;
import net.minecraft.class_3218;

public class AggressiveChaseGoal extends class_1352 {
    private static final double ATTACK_RANGE_SQ = 2.2 * 2.2;
    private static final int ATTACK_INTERVAL = 20;
    private static final float ATTACK_DAMAGE = 3.0f;

    private final class_1314 mob;
    private final double speed;
    private int attackCooldown = 0;

    public AggressiveChaseGoal(class_1314 mob, double speed) {
        this.mob = mob;
        this.speed = speed;
    }

    @Override
    public boolean method_6264() {
        class_1309 target = mob.method_5968();
        return target != null && target.method_5805();
    }

    @Override
    public boolean method_6266() {
        class_1309 target = mob.method_5968();
        if (target == null || !target.method_5805()) return false;
        return mob.method_5858(target) < 64.0 * 64.0;
    }

    @Override
    public void method_6268() {
        class_1309 target = mob.method_5968();
        if (target == null) return;

        double distSq = mob.method_5858(target);
        if (distSq > ATTACK_RANGE_SQ) {
            mob.method_5942().method_6335(target, speed);
            return;
        }

        if (attackCooldown > 0) {
            attackCooldown--;
            return;
        }
        attackCooldown = ATTACK_INTERVAL;

        if (!mob.method_5985().method_6369(target)) return;
        if (mob.method_37908() instanceof class_3218 serverLevel) {
            target.method_64397(serverLevel, mob.method_48923().method_48812(mob), ATTACK_DAMAGE);
        }
    }
}
