package com.annoyances.forJava;

import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class TeleportFrenzyAnnoyance {
    private static final Random RANDOM = new Random();
    private static final int RADIUS = 40;
    private static final long ACTION_COOLDOWN = 25;

    private static final Map<UUID, Long> actionCooldowns = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> stormTicks = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> stormHops = new ConcurrentHashMap<>();

    private static int tickCounter = 0;
    private static int nextTeleportTick = 120 + RANDOM.nextInt(120);

    public static void tickShared(class_3218 level) {
        tickCounter++;

        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            if (!hasFrenzy(level, player)) continue;

            Integer hop = stormTicks.get(player.method_5667());
            if (hop != null) {
                int ticks = hop - 1;
                if (ticks <= 0) {
                    randomTeleport(level, player, 15);
                    int left = stormHops.getOrDefault(player.method_5667(), 0) - 1;
                    if (left <= 0) {
                        stormTicks.remove(player.method_5667());
                        stormHops.remove(player.method_5667());
                    } else {
                        stormHops.put(player.method_5667(), left);
                        stormTicks.put(player.method_5667(), 8);
                    }
                } else {
                    stormTicks.put(player.method_5667(), ticks);
                }
            }
        }

        if (tickCounter < nextTeleportTick) return;
        tickCounter = 0;
        nextTeleportTick = 120 + RANDOM.nextInt(120);

        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            if (!hasFrenzy(level, player)) continue;
            if (player.method_7325()) continue;
            if (stormTicks.containsKey(player.method_5667())) continue;

            if (RANDOM.nextFloat() < 0.15f) {
                startStorm(level, player);
            } else {
                randomTeleport(level, player, RADIUS);
            }
        }
    }

    public static void tickPlayer(class_3218 level, class_3222 player) {
    }

    public static void tick(class_3218 level) {
        tickShared(level);
    }

    public static void onAttack(class_3218 level, class_3222 player, class_1297 target) {
        if (!hasFrenzy(level, player) || !consumeCooldown(player)) return;
        if (player.method_7325()) return;

        class_243 destination;
        if (target != null && target.method_5805()) {
            class_243 targetPos = target.method_19538();
            class_243 away = player.method_19538().method_1020(targetPos);
            if (away.method_1027() < 0.01) away = new class_243(1, 0, 0);
            destination = targetPos.method_1019(away.method_1029().method_1021(2.5)).method_1031(0, 0.5, 0);
        } else {
            destination = player.method_19538().method_1019(randomOffset(6, 4));
        }
        teleportTo(level, player, destination);
    }

    public static void onHurt(class_3218 level, class_3222 player) {
        if (!hasFrenzy(level, player) || !consumeCooldown(player)) return;
        randomTeleport(level, player, 24);
    }

    public static void onUse(class_3218 level, class_3222 player) {
        if (!hasFrenzy(level, player) || !consumeCooldown(player)) return;
        if (player.method_7325()) return;

        double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * 20;
        double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * 20;
        int ground = level.method_8598(class_2902.class_2903.field_13197,
                new class_2338((int) x, 0, (int) z)).method_10264();
        int y = Math.min(ground + 2 + RANDOM.nextInt(10), level.method_31607() + level.method_31605() - 5);
        teleportTo(level, player, new class_243(x, y + 0.1, z));
    }

    public static void onJump(class_3218 level, class_3222 player) {
        if (!hasFrenzy(level, player) || !consumeCooldown(player)) return;
        if (player.method_7325()) return;

        double y = Math.min(player.method_23318() + 15 + RANDOM.nextInt(25), level.method_31607() + level.method_31605() - 3);
        teleportTo(level, player, new class_243(player.method_23317(), y, player.method_23321()));
    }

    public static void reset() {
        actionCooldowns.clear();
        stormTicks.clear();
        stormHops.clear();
    }

    private static void startStorm(class_3218 level, class_3222 player) {
        stormHops.put(player.method_5667(), 3 + RANDOM.nextInt(3));
        stormTicks.put(player.method_5667(), 1);
        level.method_8396(null, player.method_24515(), class_3417.field_14879,
                class_3419.field_15256, 1.0f, 0.5f);
    }

    private static void randomTeleport(class_3218 level, class_3222 player, int radius) {
        teleportTo(level, player, destinationFor(level, player, radius));
    }

    private static class_243 destinationFor(class_3218 level, class_3222 player, int radius) {
        if (level.method_27983() == class_1937.field_25180) return netherDestination(level, player, radius);
        if (level.method_27983() == class_1937.field_25181) return endDestination(level, player, radius);
        return overworldDestination(level, player, radius);
    }

    private static class_243 netherDestination(class_3218 level, class_3222 player, int radius) {
        int top = level.method_31607() + level.method_31605() - 3;
        for (int attempt = 0; attempt < 8; attempt++) {
            double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * radius;
            double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * radius;
            int ground = level.method_8598(class_2902.class_2903.field_13197,
                    new class_2338((int) x, 0, (int) z)).method_10264();
            int y;
            if (RANDOM.nextFloat() < 0.35f) {
                y = Math.min(ground + 4 + RANDOM.nextInt(8), top);
            } else {
                y = ground + 1;
            }
            if (y - 1 >= level.method_31607()) {
                class_2338 land = new class_2338((int) x, y - 1, (int) z);
                if (!level.method_8320(land).method_27852(class_2246.field_10164)) {
                    return new class_243(x, y + 0.2, z);
                }
            }
        }
        double y = Math.min(player.method_23318() + 30 + RANDOM.nextInt(20), top);
        player.method_6092(new class_1293(class_1294.field_5918, 200, 0));
        return new class_243(player.method_23317(), y, player.method_23321());
    }

    private static class_243 endDestination(class_3218 level, class_3222 player, int radius) {
        double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * radius;
        double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * radius;
        double y = Math.min(Math.max(player.method_23318() + (RANDOM.nextDouble() * 2 - 1) * 8, level.method_31607() + 1),
                level.method_31607() + level.method_31605() - 3);
        return new class_243(x, y, z);
    }

    private static class_243 overworldDestination(class_3218 level, class_3222 player, int radius) {
        double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * radius;
        double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * radius;
        int y = level.method_8598(class_2902.class_2903.field_13197,
                new class_2338((int) x, 0, (int) z)).method_10264();
        y = Math.max(y, 1);
        return new class_243(x, y + 1.1, z);
    }

    private static void teleportTo(class_3218 level, class_3222 player, class_243 destination) {
        level.method_65096(class_2398.field_11214,
                player.method_23317(), player.method_23318() + 1, player.method_23321(),
                30, 0.3, 0.5, 0.3, 0.2);
        level.method_8396(null, player.method_24515(),
                class_3417.field_14879, class_3419.field_15248,
                1.0f, 0.8f + RANDOM.nextFloat() * 0.4f);
        player.method_5859(destination.field_1352, destination.field_1351, destination.field_1350);
        level.method_65096(class_2398.field_11214,
                destination.field_1352, destination.field_1351, destination.field_1350,
                30, 0.3, 0.5, 0.3, 0.2);
    }

    private static class_243 randomOffset(double horizontal, double vertical) {
        return new class_243(
                (RANDOM.nextDouble() * 2 - 1) * horizontal,
                (RANDOM.nextDouble() * 2 - 1) * vertical,
                (RANDOM.nextDouble() * 2 - 1) * horizontal);
    }

    private static boolean consumeCooldown(class_3222 player) {
        long now = player.method_51469().method_8510();
        Long last = actionCooldowns.get(player.method_5667());
        if (last != null && now - last < ACTION_COOLDOWN) return false;
        actionCooldowns.put(player.method_5667(), now);
        return true;
    }

    private static boolean hasFrenzy(class_3218 level, class_3222 player) {
        return AnnoyanceManager.getForPlayer(level, player) == Annoyance.TELEPORT_FRENZY;
    }
}
