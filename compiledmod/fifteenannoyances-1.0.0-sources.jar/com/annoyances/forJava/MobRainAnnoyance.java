package com.annoyances.forJava;

import java.util.List;
import java.util.Random;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1548;
import net.minecraft.class_1588;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;

public class MobRainAnnoyance {
    private static final Random RANDOM = new Random();

    private static final List<class_1299<? extends class_1588>> MOBS = List.of(
            class_1299.field_6051,
            class_1299.field_6137,
            class_1299.field_6079,
            class_1299.field_6046,
            class_1299.field_6071,
            class_1299.field_6098
    );

    private static int tickCounter = 0;
    private static int nextRainTick = 100 + RANDOM.nextInt(120);

    public static void tickShared(class_3218 level) {
        tickCounter++;

        if (tickCounter < nextRainTick) return;

        tickCounter = 0;
        nextRainTick = 100 + RANDOM.nextInt(120);

        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            if (player.method_7325()) continue;

            int count = 5 + RANDOM.nextInt(4);
            for (int i = 0; i < count; i++) {
                double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * 25;
                double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * 25;
                double y = player.method_23318() + 28 + RANDOM.nextDouble() * 8;

                if (i == 0 && RANDOM.nextDouble() < 0.15) {
                    class_1548 creeper = class_1299.field_6046.method_5883(level, class_3730.field_16467);
                    if (creeper != null) {
                        creeper.method_5814(x, y, z);
                        creeper.method_7004();
                        level.method_8649(creeper);
                    }
                    continue;
                }

                class_1308 mob = MOBS.get(RANDOM.nextInt(MOBS.size())).method_5883(level, class_3730.field_16467);
                if (mob == null) continue;
                mob.method_5814(x, y, z);
                level.method_8649(mob);
                level.method_65096(class_2398.field_11214, x, y, z, 10, 0.4, 0.2, 0.4, 0.1);
            }

            level.method_8396(null, player.method_24515(),
                    class_3417.field_14938, class_3419.field_15251,
                    0.6f, 1.2f);
        }
    }

    public static void tickPlayer(class_3218 level, class_3222 player) {
        tickShared(level);
    }

    public static void tick(class_3218 level) {
        tickShared(level);
    }
}
