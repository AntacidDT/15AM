package com.annoyances.forJava;

import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_6880;

public class IdentityCrisisAnnoyance {
    private static final Random RANDOM = new Random();
    private static final ConcurrentHashMap<UUID, MobIdentity> identities = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Integer> ticksLeft = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> teleportCooldown = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, class_1308> mirrors = new ConcurrentHashMap<>();

    private static final int EFFECT_REFRESH = 60;
    private static final float EXPLODE_CHANCE = 0.25f;
    private static final String MIRROR_MARKER = "fifteenannoyances_mirror";

    private record Effect(class_6880<class_1291> effect, int amplifier) {}

    private record MobIdentity(class_1299<?> type) {
        static MobIdentity random() {
            return new MobIdentity(ALL_MOBS.get(RANDOM.nextInt(ALL_MOBS.size())));
        }

        String displayName() {
            return type.method_5897().getString();
        }

        boolean teleports() {
            return type == class_1299.field_6091;
        }

        boolean explodes() {
            return type == class_1299.field_6046;
        }

        boolean ignites() {
            return type == class_1299.field_6099;
        }

        boolean withers() {
            return type == class_1299.field_6076;
        }

        boolean poisons() {
            return type == class_1299.field_6079 || type == class_1299.field_6084;
        }

        boolean flappy() {
            return type == class_1299.field_6132 || type == class_1299.field_6140 || type == class_1299.field_6108;
        }

        class_3414 sound() {
            if (type == class_1299.field_38384) return class_3417.field_38366;
            if (type == class_1299.field_28315) return class_3417.field_28290;
            if (type == class_1299.field_6108) return class_3417.field_15009;
            if (type == class_1299.field_20346) return class_3417.field_20605;
            if (type == class_1299.field_6099) return class_3417.field_14991;
            if (type == class_1299.field_16281) return class_3417.field_15051;
            if (type == class_1299.field_6084) return class_3417.field_15170;
            if (type == class_1299.field_6132) return class_3417.field_14871;
            if (type == class_1299.field_6070) return class_3417.field_15083;
            if (type == class_1299.field_6085) return class_3417.field_14780;
            if (type == class_1299.field_6046) return class_3417.field_15057;
            if (type == class_1299.field_6087) return class_3417.field_14799;
            if (type == class_1299.field_6067) return class_3417.field_15094;
            if (type == class_1299.field_6123) return class_3417.field_15030;
            if (type == class_1299.field_6086) return class_3417.field_15127;
            if (type == class_1299.field_6091) return class_3417.field_14696;
            if (type == class_1299.field_6128) return class_3417.field_15137;
            if (type == class_1299.field_6090) return class_3417.field_14782;
            if (type == class_1299.field_17943) return class_3417.field_18056;
            if (type == class_1299.field_37419) return class_3417.field_37313;
            if (type == class_1299.field_6107) return class_3417.field_14566;
            if (type == class_1299.field_6118) return class_3417.field_14714;
            if (type == class_1299.field_21973) return class_3417.field_22256;
            if (type == class_1299.field_6139) return class_3417.field_14947;
            if (type == class_1299.field_6071) return class_3417.field_14680;
            if (type == class_1299.field_6147) return class_3417.field_15233;
            if (type == class_1299.field_6102) return class_3417.field_14949;
            if (type == class_1299.field_6143) return class_3417.field_14780;
            if (type == class_1299.field_6057) return class_3417.field_14614;
            if (type == class_1299.field_6081) return class_3417.field_16437;
            if (type == class_1299.field_6146) return class_3417.field_14604;
            if (type == class_1299.field_6104) return class_3417.field_15132;
            if (type == class_1299.field_6078) return class_3417.field_14813;
            if (type == class_1299.field_6093) return class_3417.field_14615;
            if (type == class_1299.field_22281) return class_3417.field_22264;
            if (type == class_1299.field_6105) return class_3417.field_14976;
            if (type == class_1299.field_6042) return class_3417.field_15078;
            if (type == class_1299.field_6140) return class_3417.field_14693;
            if (type == class_1299.field_6134) return class_3417.field_14639;
            if (type == class_1299.field_6073) return class_3417.field_15033;
            if (type == class_1299.field_6115) return class_3417.field_14603;
            if (type == class_1299.field_6109) return class_3417.field_14690;
            if (type == class_1299.field_6125) return class_3417.field_14786;
            if (type == class_1299.field_6137) return class_3417.field_15200;
            if (type == class_1299.field_6069) return class_3417.field_15095;
            if (type == class_1299.field_42622) return class_3417.field_42597;
            if (type == class_1299.field_6047) return class_3417.field_14655;
            if (type == class_1299.field_6079) return class_3417.field_15170;
            if (type == class_1299.field_6114) return class_3417.field_15034;
            if (type == class_1299.field_6098) return class_3417.field_15041;
            if (type == class_1299.field_23214) return class_3417.field_23200;
            if (type == class_1299.field_6113) return class_3417.field_14722;
            if (type == class_1299.field_6059) return class_3417.field_14812;
            if (type == class_1299.field_6077) return class_3417.field_15175;
            if (type == class_1299.field_6117) return class_3417.field_14735;
            if (type == class_1299.field_38095) return class_3417.field_38062;
            if (type == class_1299.field_6145) return class_3417.field_14736;
            if (type == class_1299.field_6076) return class_3417.field_15214;
            if (type == class_1299.field_6055) return class_3417.field_14724;
            if (type == class_1299.field_23696) return class_3417.field_23672;
            if (type == class_1299.field_6051) return class_3417.field_15174;
            if (type == class_1299.field_6048) return class_3417.field_15154;
            if (type == class_1299.field_6054) return class_3417.field_15056;
            if (type == class_1299.field_6050) return class_3417.field_14926;
            return class_3417.field_14879;
        }

        Effect[] effects() {
            if (isAquatic()) {
                return new Effect[] { new Effect(class_1294.field_5923, 2), new Effect(class_1294.field_5906, 0) };
            }
            if (type == class_1299.field_6108 || type == class_1299.field_6104 || type == class_1299.field_6078
                    || type == class_1299.field_6059 || type == class_1299.field_38384 || type == class_1299.field_20346
                    || type == class_1299.field_6107 || type == class_1299.field_47244) {
                return new Effect[] { new Effect(class_1294.field_5906, 0) };
            }
            if (type == class_1299.field_6069 || type == class_1299.field_6140) {
                return new Effect[] { new Effect(class_1294.field_5913, 4), new Effect(class_1294.field_5906, 0) };
            }
            if (type == class_1299.field_6079 || type == class_1299.field_6084) {
                return new Effect[] { new Effect(class_1294.field_5913, 3), new Effect(class_1294.field_5906, 0) };
            }
            if (type == class_1299.field_6099 || type == class_1299.field_6102) {
                return new Effect[] { new Effect(class_1294.field_5918, 0) };
            }
            if (type == class_1299.field_6091) {
                return new Effect[] { new Effect(class_1294.field_38092, 0), new Effect(class_1294.field_5907, 0) };
            }
            if (isZombie()) {
                return new Effect[] { new Effect(class_1294.field_5924, 0), new Effect(class_1294.field_5903, 2) };
            }
            if (isSkeleton()) {
                return new Effect[] { new Effect(class_1294.field_5925, 0) };
            }
            if (type == class_1299.field_38095) {
                return new Effect[] { new Effect(class_1294.field_38092, 0), new Effect(class_1294.field_5907, 1), new Effect(class_1294.field_5910, 1) };
            }
            if (isTanky()) {
                return new Effect[] { new Effect(class_1294.field_5907, 0), new Effect(class_1294.field_5910, 0) };
            }
            if (type == class_1299.field_6145 || type == class_1299.field_22281) {
                return new Effect[] { new Effect(class_1294.field_5924, 0) };
            }
            if (type == class_1299.field_6109 || type == class_1299.field_47754 || type == class_1299.field_6113
                    || type == class_1299.field_42622 || type == class_1299.field_6042) {
                return new Effect[] { new Effect(class_1294.field_5907, 0) };
            }
            return new Effect[] { new Effect(class_1294.field_5906, 0) };
        }

        private boolean isAquatic() {
            return type == class_1299.field_6070 || type == class_1299.field_6073 || type == class_1299.field_6062
                    || type == class_1299.field_6111 || type == class_1299.field_6114
                    || type == class_1299.field_28402 || type == class_1299.field_6087
                    || type == class_1299.field_28315 || type == class_1299.field_37420
                    || type == class_1299.field_6113 || type == class_1299.field_6118
                    || type == class_1299.field_6086;
        }

        private boolean isZombie() {
            return type == class_1299.field_6051 || type == class_1299.field_6071 || type == class_1299.field_6123
                    || type == class_1299.field_6054 || type == class_1299.field_6048
                    || type == class_1299.field_6050 || type == class_1299.field_6095;
        }

        private boolean isSkeleton() {
            return type == class_1299.field_6137 || type == class_1299.field_6098 || type == class_1299.field_49148
                    || type == class_1299.field_6076 || type == class_1299.field_6075;
        }

        private boolean isTanky() {
            return type == class_1299.field_6147 || type == class_1299.field_6134 || type == class_1299.field_21973
                    || type == class_1299.field_23696 || type == class_1299.field_25751
                    || type == class_1299.field_6119 || type == class_1299.field_6116;
        }
    }

    private static final List<class_1299<?>> ALL_MOBS = List.of(
            class_1299.field_38384,
            class_1299.field_47754,
            class_1299.field_28315,
            class_1299.field_6108,
            class_1299.field_20346,
            class_1299.field_6099,
            class_1299.field_49148,
            class_1299.field_47244,
            class_1299.field_40116,
            class_1299.field_16281,
            class_1299.field_6084,
            class_1299.field_6132,
            class_1299.field_6070,
            class_1299.field_6085,
            class_1299.field_54560,
            class_1299.field_6046,
            class_1299.field_6087,
            class_1299.field_6067,
            class_1299.field_6123,
            class_1299.field_6086,
            class_1299.field_6116,
            class_1299.field_6091,
            class_1299.field_6128,
            class_1299.field_6090,
            class_1299.field_17943,
            class_1299.field_37419,
            class_1299.field_6107,
            class_1299.field_6095,
            class_1299.field_28402,
            class_1299.field_30052,
            class_1299.field_6118,
            class_1299.field_21973,
            class_1299.field_6139,
            class_1299.field_6071,
            class_1299.field_6065,
            class_1299.field_6147,
            class_1299.field_6074,
            class_1299.field_6102,
            class_1299.field_6143,
            class_1299.field_6057,
            class_1299.field_6081,
            class_1299.field_6146,
            class_1299.field_6104,
            class_1299.field_6078,
            class_1299.field_6093,
            class_1299.field_22281,
            class_1299.field_25751,
            class_1299.field_6105,
            class_1299.field_6042,
            class_1299.field_6062,
            class_1299.field_6140,
            class_1299.field_6134,
            class_1299.field_6073,
            class_1299.field_6115,
            class_1299.field_6109,
            class_1299.field_6125,
            class_1299.field_6137,
            class_1299.field_6075,
            class_1299.field_6069,
            class_1299.field_42622,
            class_1299.field_6047,
            class_1299.field_6079,
            class_1299.field_6114,
            class_1299.field_6098,
            class_1299.field_23214,
            class_1299.field_37420,
            class_1299.field_17714,
            class_1299.field_6111,
            class_1299.field_6113,
            class_1299.field_6059,
            class_1299.field_6077,
            class_1299.field_6117,
            class_1299.field_17713,
            class_1299.field_38095,
            class_1299.field_6145,
            class_1299.field_6119,
            class_1299.field_6076,
            class_1299.field_6055,
            class_1299.field_23696,
            class_1299.field_6051,
            class_1299.field_6048,
            class_1299.field_6054,
            class_1299.field_6050
    );

    public static void tick(class_3218 level) {
        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            if (AnnoyanceManager.getForPlayer(level, player) != Annoyance.IDENTITY_CRISIS) {
                clearIdentity(player);
                continue;
            }

            MobIdentity identity = identities.get(player.method_5667());
            if (identity == null) {
                applyIdentity(level, player, MobIdentity.random());
                continue;
            }

            if (!player.method_5805()) {
                clearIdentity(player);
                continue;
            }

            int left = ticksLeft.getOrDefault(player.method_5667(), 0) - 1;
            if (left <= 0) {
                applyIdentity(level, player, MobIdentity.random());
                continue;
            }
            ticksLeft.put(player.method_5667(), left);

            player.method_6092(new class_1293(class_1294.field_5905, EFFECT_REFRESH, 0, false, false));
            updateMirror(level, player, identity);

            for (Effect e : identity.effects()) {
                player.method_6092(new class_1293(e.effect(), EFFECT_REFRESH, e.amplifier()));
            }
            if (identity.flappy() && !player.method_5799() && RANDOM.nextFloat() < 0.03f) {
                player.method_6043();
            }
            if (identity.teleports() && tryTeleport(level, player)) {
                return;
            }
        }
    }

    private static void applyIdentity(class_3218 level, class_3222 player, MobIdentity identity) {
        MobIdentity old = identities.put(player.method_5667(), identity);
        if (old != null && old != identity) {
            removeEffects(player, old);
        }
        int duration = 120 + RANDOM.nextInt(160);
        ticksLeft.put(player.method_5667(), duration);
        teleportCooldown.remove(player.method_5667());

        removeMirror(player);
        spawnMirror(level, player, identity);
        player.method_6092(new class_1293(class_1294.field_5905, EFFECT_REFRESH, 0, false, false));

        for (Effect e : identity.effects()) {
            player.method_6092(new class_1293(e.effect(), EFFECT_REFRESH, e.amplifier()));
        }
        level.method_8396(null, player.method_24515(), identity.sound(),
                class_3419.field_15256, 1.0f, 1.0f);
        level.method_65096(class_2398.field_23114,
                player.method_23317(), player.method_23318() + 1, player.method_23321(),
                20, 0.5, 1.0, 0.5, 0.05);
    }

    private static void spawnMirror(class_3218 level, class_3222 player, MobIdentity identity) {
        class_1308 mirror = (class_1308) identity.type().method_5883(level, class_3730.field_16467);
        if (mirror == null) return;

        mirror.method_5977(true);
        mirror.method_5684(true);
        mirror.method_5875(true);
        mirror.method_5803(true);
        mirror.field_5960 = true;
        mirror.method_5971();
        mirror.method_5648(false);
        mirror.method_5980(null);
        mirror.method_5665(class_2561.method_43470(MIRROR_MARKER));
        mirror.method_5880(false);

        mirror.method_5808(player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36454(), player.method_36455());
        level.method_8649(mirror);
        mirrors.put(player.method_5667(), mirror);
    }

    private static void updateMirror(class_3218 level, class_3222 player, MobIdentity identity) {
        class_1308 mirror = mirrors.get(player.method_5667());
        if (mirror == null || !mirror.method_5805()) {
            removeMirror(player);
            spawnMirror(level, player, identity);
            return;
        }

        mirror.method_5808(player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36454(), player.method_36455());
        mirror.field_6241 = player.method_5791();
        mirror.method_18799(player.method_18798());
    }

    private static void removeMirror(class_3222 player) {
        class_1308 mirror = mirrors.remove(player.method_5667());
        if (mirror != null) {
            mirror.method_31472();
        }
    }

    private static void clearIdentity(class_3222 player) {
        MobIdentity old = identities.remove(player.method_5667());
        if (old != null) {
            removeEffects(player, old);
        }
        ticksLeft.remove(player.method_5667());
        teleportCooldown.remove(player.method_5667());
        removeMirror(player);
        player.method_6016(class_1294.field_5905);
    }

    private static void removeEffects(class_3222 player, MobIdentity identity) {
        for (Effect e : identity.effects()) {
            player.method_6016(e.effect());
        }
    }

    public static void onAttack(class_3218 level, class_3222 player, class_1297 target) {
        MobIdentity identity = identities.get(player.method_5667());
        if (identity == null) return;
        if (!(target instanceof class_1309 living)) return;

        if (identity.ignites() && !living.method_5753()) {
            living.method_20803(60);
            level.method_65096(class_2398.field_11240, living.method_23317(), living.method_23318() + 1, living.method_23321(),
                    8, 0.3, 0.3, 0.3, 0.02);
        }
        if (identity.withers()) {
            living.method_6092(new class_1293(class_1294.field_5920, 60, 1));
        }
        if (identity.poisons()) {
            living.method_6092(new class_1293(class_1294.field_5899, 60, 1));
        }
    }

    public static void onHurt(class_3218 level, class_3222 player) {
        MobIdentity identity = identities.get(player.method_5667());
        if (identity == null || !identity.explodes()) return;
        if (RANDOM.nextFloat() >= EXPLODE_CHANCE) return;

        level.method_8537(player, player.method_23317(), player.method_23318(), player.method_23321(),
                2.0f, false, class_1937.class_7867.field_40888);
    }

    private static boolean tryTeleport(class_3218 level, class_3222 player) {
        long now = level.method_8510();
        Long last = teleportCooldown.get(player.method_5667());
        if (last != null && now - last < 50) return false;
        if (player.method_5799()) return false;
        if (RANDOM.nextFloat() >= 0.06f) return false;

        teleportCooldown.put(player.method_5667(), now);
        double x = player.method_23317() + (RANDOM.nextDouble() - 0.5) * 40;
        double y = player.method_23318() + (RANDOM.nextDouble() - 0.5) * 12;
        double z = player.method_23321() + (RANDOM.nextDouble() - 0.5) * 40;

        level.method_65096(class_2398.field_11214, player.method_23317(), player.method_23318() + 1, player.method_23321(),
                12, 0.3, 0.3, 0.3, 0.05);
        player.method_5859(x, y, z);
        level.method_65096(class_2398.field_11214, x, y + 1, z, 12, 0.3, 0.3, 0.3, 0.05);
        level.method_8396(null, player.method_24515(), class_3417.field_14879,
                class_3419.field_15256, 1.0f, 1.0f);
        return true;
    }

    public static void reset() {
        for (class_1308 mirror : mirrors.values()) {
            if (mirror != null) mirror.method_31472();
        }
        mirrors.clear();
        identities.clear();
        ticksLeft.clear();
        teleportCooldown.clear();
    }
}
