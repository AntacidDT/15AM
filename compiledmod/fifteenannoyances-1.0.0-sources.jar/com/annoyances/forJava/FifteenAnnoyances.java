package com.annoyances.forJava;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_2170;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Locale;

public class FifteenAnnoyances implements ModInitializer {
    public static final String MOD_ID = "fifteenannoyances";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_3414 SCARY_SCREAM = registerSound("scary_scream");

    private static class_3414 registerSound(String name) {
        class_2960 id = class_2960.method_60655(MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41172, id,
                class_3414.method_47908(id));
    }

    @Override
    public void onInitialize() {
        ModNetworking.register();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("annoyance")
                    .executes(ctx -> {
                        class_3222 player = ctx.getSource().method_9207();
                        Annoyance active = AnnoyanceManager.get(player.method_51469());
                        if (active == Annoyance.UNKNOWN) {
                            ctx.getSource().method_9226(() -> class_2561.method_43470(
                                    "You don't know what this annoyance is..."), false);
                        } else {
                            ctx.getSource().method_9226(() -> class_2561.method_43470(
                                    "Active annoyance: " + active.getDisplayName()), false);
                        }
                        return 1;
                    })
                    .then(class_2170.method_9247("mode")
                            .then(class_2170.method_9247("shared")
                                    .requires(src -> src.method_9259(2))
                                    .executes(ctx -> {
                                        AnnoyanceManager.setMode(ctx.getSource().method_9225(),
                                                AnnoyanceManager.Mode.SHARED);
                                        ctx.getSource().method_9226(() ->
                                                class_2561.method_43470("Mode set to: Shared"), true);
                                        return 1;
                                    }))
                            .then(class_2170.method_9247("random")
                                    .requires(src -> src.method_9259(2))
                                    .executes(ctx -> {
                                        AnnoyanceManager.setMode(ctx.getSource().method_9225(),
                                                AnnoyanceManager.Mode.RANDOM);
                                        ctx.getSource().method_9226(() ->
                                                class_2561.method_43470("Mode set to: Random"), true);
                                        return 1;
                                    }))
                            .executes(ctx -> {
                                AnnoyanceManager.Mode mode = AnnoyanceManager.getMode(
                                        ctx.getSource().method_9225());
                                ctx.getSource().method_9226(() ->
                                        class_2561.method_43470("Current mode: " + mode), false);
                                return 1;
                            }))
                    .then(class_2170.method_9247("set")
                            .then(class_2170.method_9244("name", StringArgumentType.word())
                                    .suggests((ctx, builder) -> {
                                        for (Annoyance a : Annoyance.values()) {
                                            if (a != Annoyance.UNKNOWN) {
                                                builder.suggest(a.name().toLowerCase(Locale.ROOT).replace("_", ""));
                                            }
                                        }
                                        return builder.buildFuture();
                                    })
                                    .executes(ctx -> {
                                        String name = StringArgumentType.getString(ctx, "name").toUpperCase(Locale.ROOT).replace("_", "");
                                        Annoyance found = null;
                                        for (Annoyance a : Annoyance.values()) {
                                            if (a.name().replace("_", "").equals(name)) {
                                                found = a;
                                                break;
                                            }
                                        }
                                        if (found == null) {
                                            ctx.getSource().method_9213(class_2561.method_43470(
                                                    "Unknown annoyance: " + name).method_27692(class_124.field_1061));
                                            return 0;
                                        }
                                        if (found == Annoyance.UNKNOWN) {
                                            ctx.getSource().method_9213(class_2561.method_43470(
                                                    "Cannot set to UNKNOWN").method_27692(class_124.field_1061));
                                            return 0;
                                        }

                                        Annoyance chosen = found;
                                        class_3222 player = ctx.getSource().method_9207();
                                        AnnoyanceManager.setForced(player.method_51469(), chosen);

                                        for (class_3222 online : player.method_51469().method_8503().method_3760().method_14571()) {
                                            AnnoyanceReveal.playReveal(player.method_51469(), online, chosen);
                                        }

                                        ctx.getSource().method_9226(() ->
                                                class_2561.method_43470("Annoyance set to: " + chosen.getDisplayName())
                                                        .method_27692(class_124.field_1060), true);
                                        return 1;
                                    })))
            );
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            AnnoyanceManager.sendSyncPacket((class_3222) handler.method_32311());
        });

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            AnnoyanceManager.init(server.method_30002());
        });

        LOGGER.info("15 Annoyances loaded!");
    }
}
