package com.annoyances.forJava.client.mixin;

import com.annoyances.forJava.Annoyance;
import com.annoyances.forJava.client.FifteenAnnoyancesClient;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {

    private static final String MIRROR_MARKER = "fifteenannoyances_mirror";

    @Inject(method = "render(Lnet/minecraft/world/entity/Entity;DDDFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At("HEAD"), cancellable = true)
    private void fifteenannoyances$hideOwnMirror(class_1297 entity, double x, double y, double z, float partialTick,
                                                 class_4587 poseStack, class_4597 multiBufferSource, int packedLight,
                                                 CallbackInfo ci) {
        if (FifteenAnnoyancesClient.getActiveAnnoyance() != Annoyance.IDENTITY_CRISIS) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        if (!client.field_1690.method_31044().method_31034()) return;

        if (entity.method_5797() != null && MIRROR_MARKER.equals(entity.method_5797().getString())) {
            ci.cancel();
        }
    }
}
