package com.annoyances.forJava.client.mixin;

import com.annoyances.forJava.Annoyance;
import com.annoyances.forJava.client.FifteenAnnoyancesClient;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;

@Mixin(class_4184.class)
public abstract class CameraMixin {

    private static final Random RANDOM = new Random();

    @Inject(method = "setup", at = @At("RETURN"))
    private void fifteenannoyances$earthquakeShake(class_1922 level, class_1297 entity,
                                                   boolean detached, boolean thirdPersonReverse,
                                                   float partialTick, CallbackInfo ci) {
        if (FifteenAnnoyancesClient.getActiveAnnoyance() != Annoyance.EARTHQUAKE) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_243 vel = client.field_1724.method_18798();
        double speedSq = vel.method_37268() + vel.field_1351 * vel.field_1351;
        if (speedSq < 0.6) return;

        float intensity = (float) Math.min(0.12, (speedSq - 0.6) * 0.03);
        float rx = (RANDOM.nextFloat() * 2 - 1) * intensity;
        float ry = (RANDOM.nextFloat() * 2 - 1) * intensity;

        class_4184 self = (class_4184) (Object) this;
        self.method_23767().mul(new Quaternionf().rotateX(rx).rotateY(ry));
    }
}
