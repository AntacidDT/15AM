package com.annoyances.forJava.client.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_757.class)
public interface GameRendererAccessor {

    @Accessor("postEffectId")
    void fifteenannoyances$setPostEffectId(class_2960 id);

    @Accessor("effectActive")
    void fifteenannoyances$setEffectActive(boolean active);
}
