package com.annoyances.forJava.client;

import com.annoyances.forJava.Annoyance;
import java.util.Random;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

public class ClientVisuals {
    private static final Random RANDOM = new Random();

    private static final int[] CHAOS_COLORS = {
            0xFF4444, 0x44FF44, 0x4444FF, 0xFFFF44,
            0xFF44FF, 0x44FFFF, 0xFF8844, 0xFF44AA
    };

    public static void tickAmbient(class_310 client) {
        class_638 level = client.field_1687;
        class_746 player = client.field_1724;
        if (level == null || player == null) return;

        Annoyance annoyance = FifteenAnnoyancesClient.getActiveAnnoyance();
        if (annoyance == Annoyance.UNKNOWN) return;

        class_243 pos = player.method_19538();
        boolean night = (level.method_8532() % 24000) >= 13000 && (level.method_8532() % 24000) < 23000;

        switch (annoyance) {
            case OUTROVERT -> {}
            case WIND_SURGE -> spawn(level, pos, class_2398.field_11204, 0.06);
            case CHAOS -> spawnDust(level, pos);
            case EARTHQUAKE -> spawn(level, pos, class_2398.field_11251, 0.04);
            case GRAVITY_FLIP -> spawn(level, pos, class_2398.field_11216, 0.05);
            case VISION_GLITCH -> spawn(level, pos, class_2398.field_11205, 0.05);
            case TELEPORT_FRENZY -> spawn(level, pos, class_2398.field_11214, 0.05);
            case FLOOR_IS_LAVA -> spawn(level, pos, class_2398.field_11240, 0.04);
            case BLOCK_TEMPER -> {}
            case CAFFEINATED -> spawn(level, pos, class_2398.field_11215, 0.04);
            case MOB_RAIN -> spawn(level, pos, class_2398.field_11242, 0.05);
            case INTROVERTS -> spawn(level, pos, class_2398.field_11228, 0.04);
            case IDENTITY_CRISIS -> spawn(level, pos, class_2398.field_23114, 0.04);
            case AGGRESSIVE_MOBS -> spawn(level, pos, class_2398.field_11239, 0.03);
            default -> {}
        }
    }

    private static void spawn(class_638 level, class_243 pos, class_2394 particle, double speed) {
        if (RANDOM.nextDouble() < 0.6) return;
        double x = pos.field_1352 + (RANDOM.nextDouble() * 2 - 1) * 1.6;
        double y = pos.field_1351 + RANDOM.nextDouble() * 2.2;
        double z = pos.field_1350 + (RANDOM.nextDouble() * 2 - 1) * 1.6;
        level.method_8406(particle, x, y, z,
                (RANDOM.nextDouble() - 0.5) * speed * 2,
                RANDOM.nextDouble() * speed,
                (RANDOM.nextDouble() - 0.5) * speed * 2);
    }

    private static void spawnDust(class_638 level, class_243 pos) {
        if (RANDOM.nextDouble() < 0.5) return;
        int color = CHAOS_COLORS[RANDOM.nextInt(CHAOS_COLORS.length)];
        double x = pos.field_1352 + (RANDOM.nextDouble() * 2 - 1) * 2.4;
        double y = pos.field_1351 + RANDOM.nextDouble() * 2.6;
        double z = pos.field_1350 + (RANDOM.nextDouble() * 2 - 1) * 2.4;
        level.method_8406(new class_2390(color, 0.8f), x, y, z, 0, 0.02, 0);
    }
}
