package com.annoyances.forJava.client;

import com.annoyances.forJava.Annoyance;
import com.annoyances.forJava.FifteenAnnoyances;
import com.annoyances.forJava.ModNetworking;
import com.annoyances.forJava.client.mixin.GameRendererAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_757;
import net.minecraft.class_9960;

public class FifteenAnnoyancesClient implements ClientModInitializer {
    private static com.annoyances.forJava.Annoyance activeAnnoyance = com.annoyances.forJava.Annoyance.UNKNOWN;

    private static boolean drunkVisualsActive = false;
    private static int previousRenderDistance = 0;

    private static boolean visionVisualsActive = false;

    private enum VisionMode {
        GLITCH("vision_glitch", true),
        INVERT("vision_invert", true),
        MIRROR("vision_mirror", false),
        UPSIDE("vision_upside", false),
        BEHIND("vision_behind", false);

        final String chainName;
        final boolean needsTime;

        VisionMode(String chainName, boolean needsTime) {
            this.chainName = chainName;
            this.needsTime = needsTime;
        }
    }

    private static VisionMode currentVisionMode = null;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(ModNetworking.TYPE, (payload, context) -> {
            int id = payload.annoyanceId();
            class_310.method_1551().execute(() -> {
                activeAnnoyance = com.annoyances.forJava.Annoyance.fromId(id);
                FifteenAnnoyances.LOGGER.info("Client received annoyance: {}", activeAnnoyance.getDisplayName());
            });
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Annoyance annoyance = getActiveAnnoyance();

            ClientVisuals.tickAmbient(client);

            boolean drunk = annoyance == Annoyance.DRUNK;
            if (drunk != drunkVisualsActive) {
                drunkVisualsActive = drunk;
                if (drunk) {
                    previousRenderDistance = client.field_1690.method_42503().method_41753();
                    client.field_1690.method_42503().method_41748(2);
                    applyPostEffect(client, class_2960.method_60655("fifteenannoyances", "depth_blur"));
                } else {
                    client.field_1690.method_42503().method_41748(previousRenderDistance);
                    client.field_1773.method_62905();
                }
            }

            boolean vision = annoyance == Annoyance.VISION_GLITCH;
            if (vision != visionVisualsActive) {
                visionVisualsActive = vision;
                if (vision) {
                    currentVisionMode = VisionMode.GLITCH;
                    applyPostEffect(client, visionChain(currentVisionMode));
                } else {
                    currentVisionMode = null;
                    client.field_1773.method_62905();
                }
            }

            if (vision && client.field_1687 != null) {
                long ticks = client.field_1687.method_8510();
                VisionMode[] modes = VisionMode.values();
                VisionMode mode = modes[(int) ((ticks / 120) % modes.length)];
                if (mode != currentVisionMode) {
                    currentVisionMode = mode;
                    applyPostEffect(client, visionChain(mode));
                }
                if (mode.needsTime) {
                    class_279 chain = client.method_62887().method_62941(visionChain(mode), class_9960.field_53902);
                    if (chain != null) {
                        chain.method_57799("Time", (float) ticks);
                    }
                }
            }
        });

        FifteenAnnoyances.LOGGER.info("15 Annoyances client loaded!");
    }

    private static class_2960 visionChain(VisionMode mode) {
        return class_2960.method_60655("fifteenannoyances", mode.chainName);
    }

    private static void applyPostEffect(class_310 client, class_2960 id) {
        class_757 gameRenderer = client.field_1773;
        GameRendererAccessor accessor = (GameRendererAccessor) gameRenderer;
        accessor.fifteenannoyances$setPostEffectId(id);
        accessor.fifteenannoyances$setEffectActive(true);
    }

    public static com.annoyances.forJava.Annoyance getActiveAnnoyance() {
        return activeAnnoyance;
    }
}
