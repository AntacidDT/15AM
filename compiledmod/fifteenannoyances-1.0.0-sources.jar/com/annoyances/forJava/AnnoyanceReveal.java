package com.annoyances.forJava;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5888;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;

public class AnnoyanceReveal {
    private static final int TOTAL_TICKS = 80;
    private static final int INITIAL_INTERVAL = 3;
    private static final int FINAL_INTERVAL = 10;

    public static void playReveal(class_3218 level, class_3222 player, Annoyance chosen) {
        List<Annoyance> shuffled = new ArrayList<>(List.of(Annoyance.values()));
        shuffled.remove(Annoyance.UNKNOWN);
        shuffled.remove(chosen);
        Collections.shuffle(shuffled);
        shuffled.add(0, chosen);

        player.field_13987.method_14364(new class_5888(true));
        player.field_13987.method_14364(new class_5905(0, 9999, 0));

        level.method_8503().execute(new Runnable() {
            int tick = 0;
            int nameIndex = 0;

            @Override
            public void run() {
                if (tick >= TOTAL_TICKS || player.method_31481()) {
                    return;
                }

                float progress = (float) tick / TOTAL_TICKS;
                int interval = (int) (INITIAL_INTERVAL + (FINAL_INTERVAL - INITIAL_INTERVAL) * progress * progress);

                if (tick % interval == 0) {
                    Annoyance current = shuffled.get(nameIndex % shuffled.size());
                    nameIndex++;

                    class_124 color;
                    if (progress < 0.5f) {
                        color = class_124.field_1068;
                    } else if (progress < 0.8f) {
                        color = class_124.field_1054;
                    } else {
                        color = class_124.field_1065;
                    }

                    player.field_13987.method_14364(new class_5904(
                            class_2561.method_43470(current.getDisplayName())
                                    .method_27696(class_2583.field_24360.method_10977(color).method_10982(true))));

                    if (tick > 0) {
                        level.method_8396(null, player.method_24515(),
                                class_3417.field_14627, class_3419.field_15248, 0.5f, 1.5f);
                    }
                }

                if (tick == TOTAL_TICKS - 1) {
                    player.field_13987.method_14364(new class_5904(
                            class_2561.method_43470(chosen.getDisplayName())
                                    .method_27695(class_124.field_1067, class_124.field_1060)));

                    player.field_13987.method_14364(new class_5903(
                            class_2561.method_43470(chosen.getDescription())
                                    .method_27692(class_124.field_1080)));

                    player.field_13987.method_14364(new class_5905(0, 60, 20));

                    level.method_8396(null, player.method_24515(),
                            class_3417.field_14709, class_3419.field_15248, 1.0f, 1.0f);
                }

                tick++;
                if (tick <= TOTAL_TICKS) {
                    level.method_8503().execute(this);
                }
            }
        });
    }
}
