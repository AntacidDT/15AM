package com.annoyances.forJava.data;

import com.annoyances.forJava.Annoyance;
import com.annoyances.forJava.AnnoyanceManager;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

public class AnnoyanceSavedData extends class_18 {
    private static final String DATA_NAME = "fifteen_annoyances";

    public static final class_18.class_8645<AnnoyanceSavedData> TYPE =
            new class_18.class_8645<>(AnnoyanceSavedData::new, AnnoyanceSavedData::load, null);

    private AnnoyanceManager.Mode mode = AnnoyanceManager.Mode.SHARED;
    private Annoyance sharedAnnoyance = Annoyance.UNKNOWN;
    private final Map<UUID, Annoyance> playerAnnoyances = new HashMap<>();

    public AnnoyanceSavedData() {
    }

    public static AnnoyanceSavedData load(class_2487 tag, class_7225.class_7874 registries) {
        AnnoyanceSavedData data = new AnnoyanceSavedData();
        data.mode = AnnoyanceManager.Mode.valueOf(tag.method_10558("Mode"));
        data.sharedAnnoyance = Annoyance.fromId(tag.method_10550("SharedAnnoyance"));

        data.playerAnnoyances.clear();
        class_2499 playerList = tag.method_10554("PlayerAnnoyances", class_2520.field_33260);
        for (int i = 0; i < playerList.size(); i++) {
            class_2487 entry = playerList.method_10602(i);
            UUID uuid = entry.method_25926("UUID");
            Annoyance annoyance = Annoyance.fromId(entry.method_10550("Annoyance"));
            data.playerAnnoyances.put(uuid, annoyance);
        }

        return data;
    }

    @Override
    public class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        tag.method_10582("Mode", mode.name());
        tag.method_10569("SharedAnnoyance", sharedAnnoyance.getId());

        class_2499 playerList = new class_2499();
        for (Map.Entry<UUID, Annoyance> entry : playerAnnoyances.entrySet()) {
            class_2487 playerTag = new class_2487();
            playerTag.method_25927("UUID", entry.getKey());
            playerTag.method_10569("Annoyance", entry.getValue().getId());
            playerList.add(playerTag);
        }
        tag.method_10566("PlayerAnnoyances", playerList);

        return tag;
    }

    public AnnoyanceManager.Mode getMode() {
        return mode;
    }

    public void setMode(AnnoyanceManager.Mode mode) {
        this.mode = mode;
        method_80();
    }

    public Annoyance getSharedAnnoyance() {
        return sharedAnnoyance;
    }

    public void setSharedAnnoyance(Annoyance annoyance) {
        this.sharedAnnoyance = annoyance;
        method_80();
    }

    public Annoyance getPlayerAnnoyance(UUID uuid) {
        return playerAnnoyances.computeIfAbsent(uuid, k -> Annoyance.randomExcludingUnknown());
    }

    public void setPlayerAnnoyance(UUID uuid, Annoyance annoyance) {
        playerAnnoyances.put(uuid, annoyance);
        method_80();
    }

    public void clearPlayerAnnoyances() {
        playerAnnoyances.clear();
        method_80();
    }

    public static AnnoyanceSavedData get(class_3218 level) {
        return level.method_17983().method_17924(TYPE, DATA_NAME);
    }
}
