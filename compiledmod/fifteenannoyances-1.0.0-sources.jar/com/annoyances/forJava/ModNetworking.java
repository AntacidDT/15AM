package com.annoyances.forJava;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class ModNetworking {
    public static final class_2960 SYNC_ANNOUNCEMENT_ID =
            class_2960.method_60655(FifteenAnnoyances.MOD_ID, "sync_annoyance");

    public static final class_8710.class_9154<SyncAnnoyancePayload> TYPE =
            new class_8710.class_9154<>(SYNC_ANNOUNCEMENT_ID);

    public static final class_9139<class_2540, SyncAnnoyancePayload> CODEC =
            class_9139.method_56434(
                    class_9135.field_48550,
                    SyncAnnoyancePayload::annoyanceId,
                    SyncAnnoyancePayload::new
            );

    public static void register() {
        PayloadTypeRegistry.playS2C().register(TYPE, CODEC);
        PayloadTypeRegistry.playC2S().register(TYPE, CODEC);

        ServerPlayNetworking.registerGlobalReceiver(TYPE, (payload, context) -> {
        });
    }

    public static void sendToPlayer(class_3222 player, int annoyanceId) {
        ServerPlayNetworking.send(player, new SyncAnnoyancePayload(annoyanceId));
    }

    public record SyncAnnoyancePayload(int annoyanceId) implements class_8710 {
        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }
    }
}
