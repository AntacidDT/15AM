package com.annoyances.forJava;

import com.annoyances.forJava.data.AnnoyanceSavedData;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Random;

public class AnnoyanceManager {
    private static final Random RANDOM = new Random();
    private static Annoyance pendingReveal = null;

    public enum Mode {
        SHARED,
        RANDOM
    }

    public static void init(class_3218 level) {
        AnnoyanceSavedData data = AnnoyanceSavedData.get(level);

        if (data.getSharedAnnoyance() == Annoyance.UNKNOWN) {
            Annoyance chosen = Annoyance.randomExcludingUnknown();
            data.setSharedAnnoyance(chosen);
            data.method_80();
            pendingReveal = chosen;

            FifteenAnnoyances.LOGGER.info("World annoyance selected: {}", chosen.getDisplayName());
        }
    }

    public static Annoyance get(class_3218 level) {
        AnnoyanceSavedData data = AnnoyanceSavedData.get(level);
        if (data.getMode() == Mode.SHARED) {
            return data.getSharedAnnoyance();
        }
        return Annoyance.UNKNOWN;
    }

    public static Annoyance getForPlayer(class_3218 level, class_3222 player) {
        AnnoyanceSavedData data = AnnoyanceSavedData.get(level);
        if (data.getMode() == Mode.SHARED) {
            return data.getSharedAnnoyance();
        }
        return data.getPlayerAnnoyance(player.method_5667());
    }

    public static Mode getMode(class_3218 level) {
        return AnnoyanceSavedData.get(level).getMode();
    }

    public static void setMode(class_3218 level, Mode mode) {
        AnnoyanceSavedData data = AnnoyanceSavedData.get(level);
        data.setMode(mode);
        if (mode == Mode.SHARED) {
            data.setSharedAnnoyance(Annoyance.randomExcludingUnknown());
            data.clearPlayerAnnoyances();
        }
        data.method_80();
    }

    public static void setForced(class_3218 level, Annoyance annoyance) {
        AnnoyanceSavedData data = AnnoyanceSavedData.get(level);
        data.setSharedAnnoyance(annoyance);
        data.method_80();
        pendingReveal = null;

        MinecraftServer server = level.method_8503();
        for (class_3222 player : server.method_3760().method_14571()) {
            ModNetworking.sendToPlayer(player, annoyance.getId());
        }
    }

    public static void sendSyncPacket(class_3222 player) {
        class_3218 level = player.method_51469();
        AnnoyanceSavedData data = AnnoyanceSavedData.get(level);
        int annoyanceId;
        if (data.getMode() == Mode.SHARED) {
            annoyanceId = data.getSharedAnnoyance().getId();
        } else {
            annoyanceId = data.getPlayerAnnoyance(player.method_5667()).getId();
        }
        ModNetworking.sendToPlayer(player, annoyanceId);

        if (pendingReveal != null) {
            AnnoyanceReveal.playReveal(level, player, pendingReveal);
            pendingReveal = null;
        }
    }

    public static boolean isActiveForAny(class_3218 level, Annoyance annoyance) {
        AnnoyanceSavedData data = AnnoyanceSavedData.get(level);
        if (data.getMode() == Mode.SHARED) {
            return data.getSharedAnnoyance() == annoyance;
        }
        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            if (data.getPlayerAnnoyance(player.method_5667()) == annoyance) return true;
        }
        return false;
    }

    public static void tick(class_3218 level) {
        AnnoyanceSavedData data = AnnoyanceSavedData.get(level);
        Annoyance active = data.getMode() == Mode.SHARED
                ? data.getSharedAnnoyance()
                : null;

        if (active != null) {
            switch (active) {
                case OUTROVERT -> OutrovertAnnoyance.tick(level);
                case WIND_SURGE -> WindSurgeAnnoyance.tick(level);
                case CHAOS -> ChaosAnnoyance.tick(level);
                case DRUNK -> DrunkAnnoyance.tick(level);
                case BLOCK_TEMPER -> {}
                case CAFFEINATED -> CaffeinatedAnnoyance.tick(level);
                case EARTHQUAKE -> EarthquakeAnnoyance.tick(level);
                case GRAVITY_FLIP -> GravityFlipAnnoyance.tick(level);
                case TELEPORT_FRENZY -> TeleportFrenzyAnnoyance.tick(level);
                case FLOOR_IS_LAVA -> FloorIsLavaAnnoyance.tick(level);
                case MOB_RAIN -> MobRainAnnoyance.tick(level);
                case IDENTITY_CRISIS -> IdentityCrisisAnnoyance.tick(level);
                case INTROVERTS -> IntrovertsAnnoyance.tick(level);
                default -> {}
            }
            return;
        }

        boolean windSurge = false;
        boolean chaos = false;
        boolean quake = false;
        boolean gravityFlip = false;
        boolean teleport = false;
        boolean mobRain = false;
        boolean identityCrisis = false;
        boolean introverts = false;
        boolean outroverts = false;
        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            Annoyance p = data.getPlayerAnnoyance(player.method_5667());
            switch (p) {
                case OUTROVERT -> outroverts = true;
                case FLOOR_IS_LAVA -> FloorIsLavaAnnoyance.tickPlayer(level, player);
                case DRUNK -> DrunkAnnoyance.tickPlayer(level, player);
                case BLOCK_TEMPER -> {}
                case CAFFEINATED -> CaffeinatedAnnoyance.tickPlayer(level, player);
                case WIND_SURGE -> windSurge = true;
                case CHAOS -> chaos = true;
                case EARTHQUAKE -> quake = true;
                case GRAVITY_FLIP -> gravityFlip = true;
                case TELEPORT_FRENZY -> teleport = true;
                case MOB_RAIN -> mobRain = true;
                case IDENTITY_CRISIS -> identityCrisis = true;
                case INTROVERTS -> introverts = true;
                default -> {}
            }
        }
        if (windSurge) WindSurgeAnnoyance.tick(level);
        if (chaos) ChaosAnnoyance.tick(level);
        if (quake) EarthquakeAnnoyance.tick(level);
        if (gravityFlip) GravityFlipAnnoyance.tick(level);
        if (teleport) TeleportFrenzyAnnoyance.tick(level);
        if (mobRain) MobRainAnnoyance.tick(level);
        if (identityCrisis) IdentityCrisisAnnoyance.tick(level);
        if (introverts) IntrovertsAnnoyance.tick(level);
        if (outroverts) OutrovertAnnoyance.tick(level);
    }
}
