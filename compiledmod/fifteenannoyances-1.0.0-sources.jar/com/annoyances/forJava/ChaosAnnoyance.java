package com.annoyances.forJava;

import java.util.List;
import java.util.Random;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1538;
import net.minecraft.class_1542;
import net.minecraft.class_1548;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_6880;

public class ChaosAnnoyance {
    private static final Random RANDOM = new Random();

    private static final List<class_1299<? extends class_1308>> MOBS = List.of(
            class_1299.field_6051,
            class_1299.field_6137,
            class_1299.field_6079,
            class_1299.field_6046,
            class_1299.field_6071,
            class_1299.field_6078
    );

    private static final class_1792[] LOOT = {
            class_1802.field_8477, class_1802.field_8695, class_1802.field_8620, class_1802.field_8687,
            class_1802.field_8511, class_1802.field_8606, class_1802.field_8777, class_1802.field_8634,
            class_1802.field_8567, class_1802.field_8894, class_1802.field_8107, class_1802.field_8543
    };

    private static final class_6880<class_1291>[] WEIRD_EFFECTS = new class_6880[] {
            class_1294.field_5899,
            class_1294.field_5903,
            class_1294.field_5919,
            class_1294.field_38092,
            class_1294.field_5909,
            class_1294.field_5901,
            class_1294.field_5911,
            class_1294.field_5916,
            class_1294.field_5913,
            class_1294.field_5904,
            class_1294.field_5902,
            class_1294.field_5924,
            class_1294.field_5918,
            class_1294.field_5905,
            class_1294.field_5925,
            class_1294.field_5912
    };

    private static int tickCounter = 0;
    private static int nextChaosTick = 30 + RANDOM.nextInt(40);

    public static void tick(class_3218 level) {
        tickCounter++;
        if (tickCounter < nextChaosTick) return;
        tickCounter = 0;
        nextChaosTick = 30 + RANDOM.nextInt(40);

        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            if (AnnoyanceManager.getForPlayer(level, player) != Annoyance.CHAOS) continue;
            if (player.method_7325()) continue;
            fireEvent(level, player);
        }
    }

    private static void fireEvent(class_3218 level, class_3222 player) {
        switch (RANDOM.nextInt(9)) {
            case 0 -> lightningStrike(level, player);
            case 1 -> explosion(level, player);
            case 2 -> mobBurst(level, player);
            case 3 -> effectBurst(level, player);
            case 4 -> lootRain(level, player);
            case 5 -> launch(level, player);
            case 6 -> fireOutbreak(level, player);
            case 7 -> miniTeleport(level, player);
            default -> primedCreeper(level, player);
        }
    }

    private static void lightningStrike(class_3218 level, class_3222 player) {
        double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * (5 + RANDOM.nextDouble() * 4);
        double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * (5 + RANDOM.nextDouble() * 4);
        int y = level.method_8598(class_2902.class_2903.field_13197,
                new class_2338((int) x, 0, (int) z)).method_10264();

        class_1538 bolt = class_1299.field_6112.method_5883(level, class_3730.field_16467);
        if (bolt != null) {
            bolt.method_5814(x, y, z);
            level.method_8649(bolt);
        }
    }

    private static void explosion(class_3218 level, class_3222 player) {
        double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * 3;
        double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * 3;
        double y = player.method_23318() + (RANDOM.nextDouble() * 2 - 1) * 2;
        level.method_8537(null, x, y, z, 2.2f, false, class_1937.class_7867.field_40888);
    }

    private static void mobBurst(class_3218 level, class_3222 player) {
        int count = 1 + RANDOM.nextInt(3);
        for (int i = 0; i < count; i++) {
            double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * (5 + RANDOM.nextDouble() * 4);
            double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * (5 + RANDOM.nextDouble() * 4);
            int y = level.method_8598(class_2902.class_2903.field_13197,
                    new class_2338((int) x, 0, (int) z)).method_10264();

            class_1308 mob = MOBS.get(RANDOM.nextInt(MOBS.size())).method_5883(level, class_3730.field_16467);
            if (mob == null) continue;
            mob.method_5814(x, y + 0.1, z);
            level.method_8649(mob);
            level.method_65096(class_2398.field_11251, x, y + 1, z, 8, 0.4, 0.4, 0.4, 0.05);
        }
    }

    private static void effectBurst(class_3218 level, class_3222 player) {
        class_6880<class_1291> effect = WEIRD_EFFECTS[RANDOM.nextInt(WEIRD_EFFECTS.length)];
        player.method_6092(new class_1293(effect, 60 + RANDOM.nextInt(80), RANDOM.nextInt(2)));
    }

    private static void lootRain(class_3218 level, class_3222 player) {
        int count = 3 + RANDOM.nextInt(4);
        for (int i = 0; i < count; i++) {
            double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * 3;
            double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * 3;
            double y = player.method_23318() + 4 + RANDOM.nextDouble() * 4;

            class_1799 stack = new class_1799(LOOT[RANDOM.nextInt(LOOT.length)]);
            class_1542 item = new class_1542(level, x, y, z, stack);
            item.method_18800((RANDOM.nextDouble() - 0.5) * 0.3, -0.1,
                    (RANDOM.nextDouble() - 0.5) * 0.3);
            level.method_8649(item);
        }
    }

    private static void launch(class_3218 level, class_3222 player) {
        player.method_18799(player.method_18798().method_1031(0, 1.2 + RANDOM.nextDouble() * 0.6, 0));
        player.field_6037 = true;
        level.method_65096(class_2398.field_11204, player.method_23317(), player.method_23318(), player.method_23321(),
                20, 0.4, 0.1, 0.4, 0.05);
        level.method_8396(null, player.method_24515(), class_3417.field_15152.comp_349(),
                class_3419.field_15256, 0.6f, 1.6f);
    }

    private static void fireOutbreak(class_3218 level, class_3222 player) {
        player.method_20803(40);
        class_2338 pos = player.method_23312();
        for (int i = 0; i < 3; i++) {
            class_2338 target = pos.method_10069(
                    RANDOM.nextInt(7) - 3,
                    RANDOM.nextInt(2),
                    RANDOM.nextInt(7) - 3);
            if (level.method_8320(target).method_26215()) {
                level.method_8501(target, class_2246.field_10036.method_9564());
            }
        }
    }

    private static void miniTeleport(class_3218 level, class_3222 player) {
        double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * 8;
        double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * 8;
        int y = level.method_8598(class_2902.class_2903.field_13197,
                new class_2338((int) x, 0, (int) z)).method_10264();

        level.method_65096(class_2398.field_11214, player.method_23317(), player.method_23318() + 1, player.method_23321(),
                20, 0.3, 0.5, 0.3, 0.2);
        player.method_5859(x, y + 1.1, z);
        level.method_65096(class_2398.field_11214, x, y + 1.1, z, 20, 0.3, 0.5, 0.3, 0.2);
        level.method_8396(null, player.method_24515(), class_3417.field_14879,
                class_3419.field_15256, 1.0f, 0.9f);
    }

    private static void primedCreeper(class_3218 level, class_3222 player) {
        double x = player.method_23317() + (RANDOM.nextDouble() * 2 - 1) * (6 + RANDOM.nextDouble() * 4);
        double z = player.method_23321() + (RANDOM.nextDouble() * 2 - 1) * (6 + RANDOM.nextDouble() * 4);
        int y = level.method_8598(class_2902.class_2903.field_13197,
                new class_2338((int) x, 0, (int) z)).method_10264();

        class_1548 creeper = class_1299.field_6046.method_5883(level, class_3730.field_16467);
        if (creeper == null) return;
        creeper.method_5814(x, y + 0.1, z);
        creeper.method_7004();
        level.method_8649(creeper);
    }
}
