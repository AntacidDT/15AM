package com.annoyances.forJava;

import java.util.Random;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class EarthquakeAnnoyance {
    private static final Random RANDOM = new Random();
    private static int tickCounter = 0;
    private static int nextQuakeTick = 200 + RANDOM.nextInt(300);
    private static int quakeTicksLeft = 0;

    public static void tickShared(class_3218 level) {
        tickCounter++;

        if (quakeTicksLeft > 0) {
            quakeTicksLeft--;
            double strength = 0.4 + RANDOM.nextDouble() * 0.8;
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double dx = Math.cos(angle) * strength;
            double dz = Math.sin(angle) * strength;
            double dy = (RANDOM.nextDouble() - 0.35) * strength;

            for (class_3222 player : level.method_8503().method_3760().method_14571()) {
                player.method_18799(player.method_18798().method_1031(dx, dy, dz));
                player.field_6037 = true;
                level.method_65096(class_2398.field_11203,
                        player.method_23317() + (RANDOM.nextDouble() - 0.5) * 2,
                        player.method_23318(),
                        player.method_23321() + (RANDOM.nextDouble() - 0.5) * 2,
                        2, 0.5, 0.2, 0.5, 0.1);
            }

            if (quakeTicksLeft == 29 || quakeTicksLeft % 10 == 0) {
                for (class_3222 player : level.method_8503().method_3760().method_14571()) {
                    level.method_8396(null, player.method_24515(),
                            class_3417.field_15152.comp_349(), class_3419.field_15245,
                            0.3f, 0.5f + RANDOM.nextFloat() * 0.5f);
                }
            }
        }

        if (tickCounter >= nextQuakeTick) {
            quakeTicksLeft = 40 + RANDOM.nextInt(60);
            tickCounter = 0;
            nextQuakeTick = 300 + RANDOM.nextInt(400);

            for (class_3222 player : level.method_8503().method_3760().method_14571()) {
                player.method_18799(player.method_18798().method_1031(0, 1.2, 0));
                player.field_6037 = true;
            }
        }
    }

    public static void tickPlayer(class_3218 level, class_3222 player) {
        if (quakeTicksLeft > 0) {
            player.method_18799(player.method_18798().method_1031(0, 0.3, 0));
            player.field_6037 = true;
        }
    }

    public static void tick(class_3218 level) {
        tickShared(level);
    }
}
