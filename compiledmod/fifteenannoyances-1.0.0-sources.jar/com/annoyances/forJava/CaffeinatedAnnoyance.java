package com.annoyances.forJava;

import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class CaffeinatedAnnoyance {
    private static final Random RANDOM = new Random();
    private static final Map<UUID, Integer> BURST_TICKS = new ConcurrentHashMap<>();

    public static void tick(class_3218 level) {
        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            tickPlayer(level, player);
        }
    }

    public static void tickShared(class_3218 level) {
        tick(level);
    }

    public static void tickPlayer(class_3218 level, class_3222 player) {
        player.method_6092(new class_1293(class_1294.field_5917, 40, 2, false, false, true));
        player.method_6092(new class_1293(class_1294.field_5904, 40, 1, false, false, true));
        player.method_6092(new class_1293(class_1294.field_5913, 40, 1, false, false, true));

        Integer burst = BURST_TICKS.get(player.method_5667());
        if (burst != null) {
            burst--;
            if (burst <= 0) {
                BURST_TICKS.remove(player.method_5667());
            } else {
                player.method_6092(new class_1293(class_1294.field_5904, 40, 5, false, false, true));
                player.method_6092(new class_1293(class_1294.field_5913, 40, 4, false, false, true));
                player.method_6092(new class_1293(class_1294.field_5925, 40, 0, false, false, true));
                level.method_65096(new class_2390(0x88FF22, 0.8f),
                        player.method_23317(), player.method_23318() + 0.8, player.method_23321(),
                        2, 0.2, 0.2, 0.2, 0);
                BURST_TICKS.put(player.method_5667(), burst);
            }
        } else if (RANDOM.nextDouble() < 0.004) {
            BURST_TICKS.put(player.method_5667(), 100);
            level.method_8396(null, player.method_24515(), class_3417.field_14726,
                    class_3419.field_15248, 0.8f, 2.0f);
        }

        if (player.method_24828() && RANDOM.nextDouble() < 0.06) {
            player.method_6043();
        }

        class_243 motion = player.method_18798();
        if (motion.method_37268() > 0.0025) {
            double jitterX = (RANDOM.nextDouble() - 0.5) * 0.2;
            double jitterZ = (RANDOM.nextDouble() - 0.5) * 0.2;
            player.method_18800(motion.field_1352 + jitterX, motion.field_1351, motion.field_1350 + jitterZ);
            player.field_6037 = true;
        }

        if (motion.method_37268() > 0.25 && RANDOM.nextDouble() < 0.5) {
            level.method_65096(new class_2390(0xFF2222, 0.8f),
                    player.method_23317(), player.method_23318() + 0.5, player.method_23321(),
                    1, 0.1, 0.1, 0.1, 0);
        }

        if (RANDOM.nextDouble() < 0.01) {
            level.method_8396(null, player.method_24515(),
                    class_3417.field_14726, class_3419.field_15248,
                    0.6f, 1.8f);
        }
    }
}
