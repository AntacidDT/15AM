package com.annoyances.forJava;

import java.util.Random;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class GravityFlipAnnoyance {
    private static final Random RANDOM = new Random();
    private static int tickCounter = 0;
    private static int nextFlipTick = 200 + RANDOM.nextInt(300);
    private static int flipTicksLeft = 0;
    private static int graceTicks = 0;

    private static boolean isAffected(class_3218 level, class_3222 player) {
        return AnnoyanceManager.getForPlayer(level, player) == Annoyance.GRAVITY_FLIP
                && !player.method_7337() && !player.method_7325();
    }

    public static void tryTrigger(class_3218 level, class_3222 player) {
        if (AnnoyanceManager.getForPlayer(level, player) != Annoyance.GRAVITY_FLIP) return;
        if (player.method_7337() || player.method_7325()) return;
        if (flipTicksLeft > 0) return;
        if (RANDOM.nextFloat() >= 0.18f) return;

        startFlip(level);
    }

    private static void startFlip(class_3218 level) {
        flipTicksLeft = 80 + RANDOM.nextInt(120);
        tickCounter = 0;
        nextFlipTick = 300 + RANDOM.nextInt(500);
        graceTicks = 0;

        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            level.method_8396(null, player.method_24515(),
                    class_3417.field_14879, class_3419.field_15256,
                    1.0f, 0.7f);
        }
    }

    public static void tickShared(class_3218 level) {
        tickCounter++;

        if (tickCounter == nextFlipTick - 40) {
            for (class_3222 player : level.method_8503().method_3760().method_14571()) {
                if (!isAffected(level, player)) continue;
                level.method_65096(class_2398.field_11214,
                        player.method_23317(), player.method_23318() + 1, player.method_23321(),
                        6, 0.5, 1.0, 0.5, 0.02);
            }
        }

        if (tickCounter >= nextFlipTick) {
            startFlip(level);
        }

        if (flipTicksLeft > 0) {
            flipTicksLeft--;
            graceTicks = 40;
            for (class_3222 player : level.method_8503().method_3760().method_14571()) {
                if (!isAffected(level, player)) continue;
                tickFlipped(level, player);
            }
        } else if (graceTicks > 0) {
            graceTicks--;
            for (class_3222 player : level.method_8503().method_3760().method_14571()) {
                if (!isAffected(level, player)) continue;
                player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, true));
            }
        }
    }

    private static void tickFlipped(class_3218 level, class_3222 player) {
        player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, true));

        if (player.method_5799()) return;

        class_243 motion = player.method_18798();

        if (player.method_5715()) {
            // Counter: sneaking stabilizes you — normal gravity pulls you down, no lift.
            player.method_18800(motion.field_1352 * 0.95, Math.max(motion.field_1351 * 0.95 - 0.06, -0.5), motion.field_1350 * 0.95);
            player.field_6007 = true;
            if (RANDOM.nextDouble() < 0.1) {
                level.method_65096(class_2398.field_22447,
                        player.method_23317() + (RANDOM.nextDouble() - 0.5) * 1.5,
                        player.method_23318() + 1.0,
                        player.method_23321() + (RANDOM.nextDouble() - 0.5) * 1.5,
                        1, 0, 0, 0, 0);
            }
            return;
        }

        player.method_18800(motion.field_1352, Math.min(motion.field_1351 * 0.92 + 0.09, 0.6), motion.field_1350);
        player.field_6007 = true;
        level.method_65096(class_2398.field_11216,
                player.method_23317() + (RANDOM.nextDouble() - 0.5) * 2,
                player.method_23318() + RANDOM.nextDouble() * 2,
                player.method_23321() + (RANDOM.nextDouble() - 0.5) * 2,
                1, 0, 0.15, 0, 0.05);
    }

    public static void tick(class_3218 level) {
        tickShared(level);
    }
}
