package com.annoyances.forJava;

import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3486;

public class FloorIsLavaAnnoyance {
    private static final int IGNITE_TICKS = 35;
    private static final int EVAPORATE_INTERVAL = 20;
    private static final int EVAPORATE_RADIUS = 4;

    private static final Random RANDOM = new Random();
    private static final Map<UUID, Integer> STANDING_TICKS = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> EVAPORATE_TICKS = new ConcurrentHashMap<>();

    public static void tickShared(class_3218 level) {
        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            tickPlayer(level, player);
        }
    }

    public static void tickPlayer(class_3218 level, class_3222 player) {
        if (player.method_20802() > 0 && RANDOM.nextDouble() < 0.4) {
            level.method_65096(class_2398.field_11240,
                    player.method_23317() + (RANDOM.nextDouble() - 0.5) * 1.5,
                    player.method_23318() + 0.1,
                    player.method_23321() + (RANDOM.nextDouble() - 0.5) * 1.5,
                    1, 0, 0, 0, 0);
        }

        int evapTicks = EVAPORATE_TICKS.getOrDefault(player.method_5667(), 0) + 1;
        if (evapTicks >= EVAPORATE_INTERVAL) {
            EVAPORATE_TICKS.put(player.method_5667(), 0);
            evaporateWater(level, player);
        } else {
            EVAPORATE_TICKS.put(player.method_5667(), evapTicks);
        }

        boolean standing = player.method_24828()
                && player.method_18798().method_37268() < 0.0025;

        if (!standing) {
            STANDING_TICKS.remove(player.method_5667());
            return;
        }

        int ticks = STANDING_TICKS.getOrDefault(player.method_5667(), 0) + 1;
        if (ticks < IGNITE_TICKS) {
            STANDING_TICKS.put(player.method_5667(), ticks);
            return;
        }

        STANDING_TICKS.put(player.method_5667(), 0);

        class_2338 pos = player.method_23312();
        if (pos != null && level.method_8320(pos).method_26215()) {
            level.method_8501(pos, class_2246.field_10036.method_9564());
        }

        for (int i = 0; i < 2; i++) {
            class_2338 target = pos.method_10069(RANDOM.nextInt(5) - 2, 0, RANDOM.nextInt(5) - 2);
            if (level.method_8320(target).method_26215()) {
                level.method_8501(target, class_2246.field_10036.method_9564());
            }
        }

        if (pos != null) {
            class_2338 below = pos.method_10074();
            class_2680 belowState = level.method_8320(below);
            if (belowState.method_26215() || belowState.method_26227().method_15767(class_3486.field_15517)) {
                level.method_8501(below, class_2246.field_10164.method_9564());
            }
            if (RANDOM.nextDouble() < 0.25) {
                class_2338 adjacent = below.method_10069(RANDOM.nextInt(3) - 1, 0, RANDOM.nextInt(3) - 1);
                class_2680 adjState = level.method_8320(adjacent);
                if (adjState.method_26215() || adjState.method_26227().method_15767(class_3486.field_15517)) {
                    level.method_8501(adjacent, class_2246.field_10164.method_9564());
                }
            }
        }

        player.method_20803(60);
    }

    private static void evaporateWater(class_3218 level, class_3222 player) {
        class_2338 center = player.method_24515();
        boolean evaporated = false;
        for (int dx = -EVAPORATE_RADIUS; dx <= EVAPORATE_RADIUS; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -EVAPORATE_RADIUS; dz <= EVAPORATE_RADIUS; dz++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    class_2680 state = level.method_8320(pos);
                    if (!state.method_26227().method_15767(class_3486.field_15517)) continue;

                    level.method_8501(pos, class_2246.field_10124.method_9564());
                    level.method_65096(class_2398.field_11204,
                            pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                            4, 0.3, 0.3, 0.3, 0.02);
                    level.method_65096(class_2398.field_11251,
                            pos.method_10263() + 0.5, pos.method_10264() + 0.8, pos.method_10260() + 0.5,
                            2, 0.1, 0.1, 0.1, 0.01);
                    evaporated = true;
                }
            }
        }
        if (evaporated) {
            level.method_8396(null, center, net.minecraft.class_3417.field_15102,
                    net.minecraft.class_3419.field_15245, 0.8f, 0.5f + RANDOM.nextFloat() * 0.5f);
        }
    }

    public static void tick(class_3218 level) {
        tickShared(level);
    }
}
