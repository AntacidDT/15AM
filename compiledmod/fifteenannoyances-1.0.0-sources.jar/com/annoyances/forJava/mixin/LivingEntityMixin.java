package com.annoyances.forJava.mixin;

import com.annoyances.forJava.*;
import net.minecraft.class_1309;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @Inject(method = "jumpFromGround", at = @At("HEAD"))
    private void onJump(CallbackInfo ci) {
        if (!((Object) this instanceof class_3222 player)) return;
        if (player.method_51469() == null) return;
        GravityFlipAnnoyance.tryTrigger(player.method_51469(), player);
        TeleportFrenzyAnnoyance.onJump(player.method_51469(), player);
    }

    @Inject(method = "jumpFromGround", at = @At("TAIL"))
    private void onJumpTail(CallbackInfo ci) {
        if (!((Object) this instanceof class_3222 player)) return;
        if (player.method_51469() == null) return;

        Annoyance annoyance = AnnoyanceManager.getForPlayer(player.method_51469(), player);
        switch (annoyance) {
            default -> {}
        }
    }
}
