package com.annoyances.forJava.mixin;

import com.annoyances.forJava.BlockTemperAnnoyance;
import com.annoyances.forJava.GravityFlipAnnoyance;
import com.annoyances.forJava.TeleportFrenzyAnnoyance;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public abstract class ServerPlayerGameModeMixin {

    @Shadow @Final protected class_3222 player;

    @Inject(method = "destroyBlock", at = @At("HEAD"))
    private void onDestroyBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        if (player.method_51469() == null) return;
        GravityFlipAnnoyance.tryTrigger(player.method_51469(), player);
        BlockTemperAnnoyance.onBlockBreak(player.method_51469(), player, pos);
    }

    @Inject(method = "useItem", at = @At("HEAD"))
    private void onUseItem(class_3222 player, class_1937 level, class_1799 stack, class_1268 hand,
                           CallbackInfoReturnable<class_1269> cir) {
        if (player.method_51469() == null) return;
        GravityFlipAnnoyance.tryTrigger(player.method_51469(), player);
        TeleportFrenzyAnnoyance.onUse(player.method_51469(), player);
    }

    @Inject(method = "useItemOn", at = @At("HEAD"))
    private void onUseItemOn(class_3222 player, class_1937 level, class_1799 stack, class_1268 hand,
                             class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        if (player.method_51469() == null) return;
        GravityFlipAnnoyance.tryTrigger(player.method_51469(), player);
        TeleportFrenzyAnnoyance.onUse(player.method_51469(), player);
    }
}
