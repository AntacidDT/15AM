package com.annoyances.forJava.mixin;

import com.annoyances.forJava.*;
import com.mojang.datafixers.util.Either;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3222.class)
public abstract class PlayerEntityMixin {

    @Inject(method = "startSleepInBed", at = @At("HEAD"), cancellable = true)
    private void onStartSleepInBed(class_2338 pos, CallbackInfoReturnable<Either<class_1657.class_1658, ?>> cir) {
        class_3222 player = (class_3222) (Object) this;
        if (player.method_51469() == null) return;

        Annoyance annoyance = AnnoyanceManager.getForPlayer(player.method_51469(), player);
        if (annoyance == Annoyance.CAFFEINATED) {
            player.method_7353(
                    net.minecraft.class_2561.method_43470("You're too caffeinated to sleep!"),
                    true);
            cir.setReturnValue(Either.left(class_1657.class_1658.field_7531));
        }
    }

    @Inject(method = "attack(Lnet/minecraft/world/entity/Entity;)V", at = @At("HEAD"))
    private void onAttack(net.minecraft.class_1297 target, CallbackInfo ci) {
        class_3222 player = (class_3222) (Object) this;
        if (player.method_51469() == null) return;

        IdentityCrisisAnnoyance.onAttack(player.method_51469(), player, target);
        GravityFlipAnnoyance.tryTrigger(player.method_51469(), player);
        TeleportFrenzyAnnoyance.onAttack(player.method_51469(), player, target);
    }
}
