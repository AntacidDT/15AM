package com.annoyances.forJava.mixin;

import com.annoyances.forJava.AggressiveChaseGoal;
import com.annoyances.forJava.Annoyance;
import com.annoyances.forJava.AnnoyanceManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1314;
import net.minecraft.class_1324;
import net.minecraft.class_1352;
import net.minecraft.class_1355;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

@Mixin(class_1308.class)
public abstract class MobMixin {

    private static final Map<UUID, class_1352> BUFFED_MOBS = new HashMap<>();
    private static final Map<UUID, Double> ORIGINAL_SPEED = new HashMap<>();
    private static final double BOOSTED_SPEED = 0.35;

    @Shadow
    protected class_1355 goalSelector;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_1308 mob = (class_1308) (Object) this;
        if (!(mob.method_37908() instanceof class_3218 level)) return;

        boolean active = AnnoyanceManager.isActiveForAny(level, Annoyance.AGGRESSIVE_MOBS);

        if (!active) {
            class_1352 buffed = BUFFED_MOBS.remove(mob.method_5667());
            if (buffed != null) {
                goalSelector.method_6280(buffed);
            }
            Double orig = ORIGINAL_SPEED.remove(mob.method_5667());
            if (orig != null) {
                class_1324 speedAttr = mob.method_5996(class_5134.field_23719);
                if (speedAttr != null) speedAttr.method_6192(orig);
            }
            return;
        }

        UUID id = mob.method_5667();
        boolean isMonster = mob.method_5864().method_5891() == class_1311.field_6302;

        if (!isMonster && mob instanceof class_1314 pathfinder && !BUFFED_MOBS.containsKey(id)) {
            class_1352 goal = new AggressiveChaseGoal(pathfinder, 1.3);
            goalSelector.method_6277(3, goal);
            BUFFED_MOBS.put(id, goal);
        }

        class_1324 speedAttr = mob.method_5996(class_5134.field_23719);
        if (speedAttr != null) {
            if (!ORIGINAL_SPEED.containsKey(id)) {
                ORIGINAL_SPEED.put(id, speedAttr.method_6201());
            }
            speedAttr.method_6192(BOOSTED_SPEED);
        }

        class_3222 nearest = null;
        double bestDistSq = 64.0 * 64.0;
        for (class_3222 player : level.method_18456()) {
            if (player.method_7325() || player.method_31549().field_7477) continue;

            double distSq = player.method_5858(mob);
            if (distSq < bestDistSq) {
                bestDistSq = distSq;
                nearest = player;
            }
        }

        if (nearest == null) return;

        mob.method_5980(nearest);

        if (mob.method_5799()) {
            class_243 toTarget = nearest.method_19538().method_1020(mob.method_19538());
            double dist = toTarget.method_1033();
            if (dist > 1.5) {
                class_243 dir = toTarget.method_1029();
                mob.method_18799(dir.method_1021(0.3));
                mob.field_6037 = true;
            }
        }

        if (mob.field_6012 % 5 == 0 && mob.method_5968() instanceof class_3222) {
            level.method_65096(new class_2390(0xFF0000, 0.9f),
                    mob.method_23317(), mob.method_23318() + mob.method_5751(), mob.method_23321(),
                    1, 0.1, 0.1, 0.1, 0);
        }
    }
}
