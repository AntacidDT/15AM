package com.annoyances.forJava.mixin;

import com.annoyances.forJava.IdentityCrisisAnnoyance;
import com.annoyances.forJava.TeleportFrenzyAnnoyance;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class PlayerMixin {

    @Inject(method = "hurtServer", at = @At("HEAD"))
    private void onHurtServer(class_3218 level, class_1282 source, float amount,
                              CallbackInfoReturnable<Boolean> cir) {
        if (!((Object) this instanceof class_3222 player)) return;
        IdentityCrisisAnnoyance.onHurt(level, player);
        TeleportFrenzyAnnoyance.onHurt(level, player);
    }
}
