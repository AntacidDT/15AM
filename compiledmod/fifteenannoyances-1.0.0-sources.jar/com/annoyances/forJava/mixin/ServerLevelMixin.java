package com.annoyances.forJava.mixin;

import com.annoyances.forJava.AnnoyanceManager;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3218.class)
public abstract class ServerLevelMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_3218 level = (class_3218) (Object) this;
        if (level.method_27983().equals(level.method_8503().method_30002().method_27983())) {
            AnnoyanceManager.tick(level);
        }
    }
}
