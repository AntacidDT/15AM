package com.annoyances.forJava;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1308;
import net.minecraft.class_1324;
import net.minecraft.class_1408;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

public class OutrovertAnnoyance {
    private static final Random RANDOM = new Random();
    private static final double RADIUS = 20.0;
    private static final double RUSH_SPEED = 1.5;
    private static final double BOOSTED_SPEED = 0.35;
    private static final Map<UUID, Double> originalSpeed = new HashMap<>();
    private static final Set<UUID> affectedMobs = new HashSet<>();

    public static void tick(class_3218 level) {
        Set<UUID> currentlyAffected = new HashSet<>();

        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            if (AnnoyanceManager.getForPlayer(level, player) != Annoyance.OUTROVERT) continue;
            if (player.method_7325()) continue;

            List<class_1308> mobs = level.method_8390(class_1308.class,
                    new class_238(player.method_24515()).method_1014(RADIUS),
                    m -> m.method_5805());
            for (class_1308 mob : mobs) {
                UUID id = mob.method_5667();
                currentlyAffected.add(id);
                mob.method_5980(null);

                class_1324 speedAttr = mob.method_5996(class_5134.field_23719);
                if (speedAttr != null) {
                    if (!originalSpeed.containsKey(id)) {
                        originalSpeed.put(id, speedAttr.method_6201());
                    }
                    speedAttr.method_6192(BOOSTED_SPEED);
                }

                class_1408 nav = mob.method_5942();
                nav.method_6340();
                nav.method_6337(player.method_23317(), player.method_23318(), player.method_23321(), RUSH_SPEED);

                if (mob.method_5799()) {
                    class_243 toPlayer = player.method_19538().method_1020(mob.method_19538());
                    double dist = toPlayer.method_1033();
                    if (dist > 1.5) {
                        class_243 dir = toPlayer.method_1029();
                        mob.method_18799(dir.method_1021(0.3));
                        mob.field_6037 = true;
                    }
                }
            }
        }

        for (UUID id : affectedMobs) {
            if (!currentlyAffected.contains(id)) {
                class_1308 mob = (class_1308) level.method_14190(id);
                if (mob != null) {
                    Double orig = originalSpeed.remove(id);
                    if (orig != null) {
                        class_1324 speedAttr = mob.method_5996(class_5134.field_23719);
                        if (speedAttr != null) speedAttr.method_6192(orig);
                    }
                }
            }
        }
        affectedMobs.clear();
        affectedMobs.addAll(currentlyAffected);
    }

    public static void reset() {
        originalSpeed.clear();
        affectedMobs.clear();
    }
}
