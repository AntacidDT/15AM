package com.annoyances.forJava;

import java.util.Random;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class DrunkAnnoyance {

    private static final Random RANDOM = new Random();

    public static void tick(class_3218 level) {
        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            tickPlayer(level, player);
        }
    }

    public static void tickShared(class_3218 level) {
        tick(level);
    }

    public static void tickPlayer(class_3218 level, class_3222 player) {
        class_1293 current = player.method_6112(class_1294.field_5916);
        if (current == null || current.method_5584() < 40) {
            player.method_6092(new class_1293(class_1294.field_5916,
                    60, 255, false, false, true));
        }

        if (RANDOM.nextDouble() < 0.02) {
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double strength = 0.15 + RANDOM.nextDouble() * 0.2;
            class_243 motion = player.method_18798();
            player.method_18800(
                    motion.field_1352 + Math.cos(angle) * strength,
                    motion.field_1351 + RANDOM.nextDouble() * 0.1,
                    motion.field_1350 + Math.sin(angle) * strength);
            player.field_6037 = true;
            level.method_65096(class_2398.field_11251,
                    player.method_23317(), player.method_23318() + 0.6, player.method_23321(),
                    2, 0.3, 0.3, 0.3, 0.02);
        }
    }
}
