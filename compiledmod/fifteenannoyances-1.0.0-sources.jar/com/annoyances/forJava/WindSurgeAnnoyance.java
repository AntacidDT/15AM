package com.annoyances.forJava;

import java.util.Random;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class WindSurgeAnnoyance {
    private static final Random RANDOM = new Random();
    private static int tickCounter = 0;
    private static int nextGustTick = 40 + RANDOM.nextInt(60);
    private static int gustDuration = 0;
    private static int gustTotalDuration = 0;
    private static double gustAngle = 0;
    private static double gustSpin = 0;
    private static double gustForce = 0;
    private static double gustDy = 0;
    private static boolean spinning = false;

    public static void tickShared(class_3218 level) {
        tickCounter++;

        if (gustDuration > 0) {
            gustDuration--;
            gustAngle += gustSpin;
            float progress = (float) gustDuration / gustTotalDuration;
            double forceMultiplier = progress < 0.3f ? progress / 0.3f : 1.0;
            double dx = Math.cos(gustAngle) * gustForce * forceMultiplier;
            double dz = Math.sin(gustAngle) * gustForce * forceMultiplier;

            for (class_3222 player : level.method_8503().method_3760().method_14571()) {
                player.method_18799(
                        player.method_18798().method_1031(dx, gustDy * forceMultiplier, dz)
                );
                player.field_6037 = true;
                if (spinning) {
                    player.method_36456(player.method_36454() + 12.0f);
                }
                level.method_65096(class_2398.field_11204,
                        player.method_23317(), player.method_23318() + 1, player.method_23321(),
                        3, dx * 0.6, 0.1, dz * 0.6, 0.05);
            }

            if (gustDuration == gustTotalDuration - 1 || gustDuration % 15 == 0) {
                playWindSound(level);
            }
        }

        if (tickCounter >= nextGustTick) {
            gustTotalDuration = 40 + RANDOM.nextInt(60);
            gustDuration = gustTotalDuration;
            gustForce = 0.5 + RANDOM.nextDouble() * 0.9;
            gustAngle = RANDOM.nextDouble() * Math.PI * 2;
            gustSpin = (RANDOM.nextDouble() - 0.5) * 0.1;
            gustDy = RANDOM.nextDouble() < 0.6 ? 0.15 + RANDOM.nextDouble() * 0.35 : 0;
            spinning = RANDOM.nextDouble() < 0.15;

            tickCounter = 0;
            nextGustTick = 60 + RANDOM.nextInt(100);
        }
    }

    public static void tickPlayer(class_3218 level, class_3222 player) {
        if (gustDuration > 0) {
            float progress = (float) gustDuration / gustTotalDuration;
            double forceMultiplier = progress < 0.3f ? progress / 0.3f : 1.0;
            double dx = Math.cos(gustAngle) * gustForce * forceMultiplier;
            double dz = Math.sin(gustAngle) * gustForce * forceMultiplier;
            player.method_18799(player.method_18798().method_1031(dx, gustDy * forceMultiplier, dz));
            player.field_6037 = true;
        }
    }

    public static void tick(class_3218 level) {
        tickShared(level);
    }

    private static void playWindSound(class_3218 level) {
        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            level.method_8396(null, player.method_24515(),
                    class_3417.field_15203, class_3419.field_15252,
                    0.5f, 0.8f + RANDOM.nextFloat() * 0.4f);
        }
    }
}
