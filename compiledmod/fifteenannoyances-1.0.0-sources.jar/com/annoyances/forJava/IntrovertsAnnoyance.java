package com.annoyances.forJava;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.class_1308;
import net.minecraft.class_1408;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;

public class IntrovertsAnnoyance {
    private static final Random RANDOM = new Random();
    private static final double RADIUS = 14.0;
    private static final double FLEE_DISTANCE = 32.0;
    private static final double FLEE_SPEED = 1.8;
    private static final Map<UUID, Long> startleCooldown = new HashMap<>();
    private static long lastScreamTick = Long.MIN_VALUE;
    private static int tickCounter = 0;

    public static void tick(class_3218 level) {
        tickCounter++;
        if (tickCounter % 2 != 0) return;

        for (class_3222 player : level.method_8503().method_3760().method_14571()) {
            if (AnnoyanceManager.getForPlayer(level, player) != Annoyance.INTROVERTS) continue;
            if (player.method_7325()) continue;

            List<class_1308> mobs = level.method_8390(class_1308.class,
                    new class_238(player.method_24515()).method_1014(RADIUS),
                    m -> m.method_5805());
            for (class_1308 mob : mobs) {
                class_243 away = mob.method_19538().method_1020(player.method_19538());
                if (away.method_1027() < 1.0E-4) {
                    away = new class_243(RANDOM.nextDouble() - 0.5, 0, RANDOM.nextDouble() - 0.5);
                }
                away = away.method_1029();
                class_243 target = mob.method_19538().method_1019(away.method_1021(FLEE_DISTANCE));

                mob.method_5980(null);
                class_1408 nav = mob.method_5942();
                nav.method_6340();
                nav.method_6337(target.field_1352, mob.method_23318(), target.field_1350, FLEE_SPEED);

                long now = level.method_8510();
                Long last = startleCooldown.get(mob.method_5667());
                if (last == null || now - last > 100) {
                    startleCooldown.put(mob.method_5667(), now);
                    level.method_65096(class_2398.field_11204,
                            mob.method_23317(), mob.method_23318() + 0.5, mob.method_23321(),
                            6, 0.3, 0.3, 0.3, 0.03);
                    if (now - lastScreamTick >= 15) {
                        lastScreamTick = now;
                        level.method_8396(null, mob.method_24515(), FifteenAnnoyances.SCARY_SCREAM,
                                class_3419.field_15256, 1.0f, 1.0f);
                        FifteenAnnoyances.LOGGER.info("Scary scream fired at {}", mob.method_24515());
                    }
                }
            }
        }
    }

    public static void reset() {
        startleCooldown.clear();
    }
}
